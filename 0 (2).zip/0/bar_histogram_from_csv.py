
import pandas as pd
import matplotlib.pyplot as plt

# Load the data
df = pd.read_csv("API_SP.POP.TOTL_DS2_en_csv_v2_20333.csv", skiprows=4)

# Extract 2023 data
df_2023 = df[["Country Name", "2023"]].dropna()
df_2023.columns = ["Country", "Population"]
df_2023 = df_2023.sort_values(by="Population", ascending=False)

# Top 10 bar chart
top_10 = df_2023.head(10)

plt.figure(figsize=(12, 6))
bars = plt.bar(top_10["Country"], top_10["Population"], color="cornflowerblue")
plt.title("Top 10 Most Populous Countries (2023)", fontsize=16)
plt.xlabel("Country", fontsize=12)
plt.ylabel("Population", fontsize=12)
plt.xticks(rotation=45)
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height + 1e7, f'{height/1e9:.2f}B',
             ha='center', va='bottom', fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# Histogram for all countries
plt.figure(figsize=(10, 6))
plt.hist(df_2023["Population"] / 1e6, bins=10, color='mediumseagreen', edgecolor='black')
plt.title("Histogram of Country Populations (2023)", fontsize=16)
plt.xlabel("Population (in millions)", fontsize=12)
plt.ylabel("Number of Countries", fontsize=12)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

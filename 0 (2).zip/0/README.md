
# Population Data Visualization

This project visualizes the population data of countries using:
- A bar chart showing the top 10 most populous countries in 2023.
- A histogram showing the distribution of populations for all countries in 2023.

## Files Included
- `bar_histogram_from_csv.py`: Python script for visualization.
- `API_SP.POP.TOTL_DS2_en_csv_v2_20333.csv`: Raw population data from World Bank.
- `README.md`: This file.
- `LICENSE`: License information.

## How to Run

1. Make sure you have Python 3 installed.
2. Install the required libraries:

```bash
pip install pandas matplotlib
```

3. Run the script:

```bash
python bar_histogram_from_csv.py
```

## Data Source

[World Bank - Total Population](https://data.worldbank.org/indicator/SP.POP.TOTL)
